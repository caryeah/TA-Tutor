package com.example.jobportal;
import android.support.v7.widget.Toolbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AllJobActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_job);
    }
}